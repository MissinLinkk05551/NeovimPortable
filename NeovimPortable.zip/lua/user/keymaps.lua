local map = vim.keymap.set
local opts = { noremap = true, silent = true }

-- Increment/decrement numbers
map("n", "<C-a>", require("dial.map").inc_normal(), opts)
map("n", "<C-x>", require("dial.map").dec_normal(), opts)
map("v", "<C-a>", require("dial.map").inc_visual(), opts)
map("v", "<C-x>", require("dial.map").dec_visual(), opts)
map("v", "g<C-a>", require("dial.map").inc_gvisual(), opts)
map("v", "g<C-x>", require("dial.map").dec_gvisual(), opts)

-- Commenting
map({ "n", "v" }, "<leader>/", function() require("Comment.api").toggle.linewise.current() end, opts)
